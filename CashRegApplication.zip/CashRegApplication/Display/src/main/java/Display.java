/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author taimo
 */
import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

public class Display extends JFrame{
    
    Scanner sc= new Scanner(System.in);
    long code = sc.nextInt(); 
 
    public Display() {
        init();
    }
 
    private void init() {
        setLayout(new FlowLayout());
        add(new JLabel("Your code is " + code));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(640, 480);
        setLocationRelativeTo(null);
    }
    
    public static void main(String[] args) {
        System.out.println("Enter code");
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Display().setVisible(true);
            }
        });
    }

}
